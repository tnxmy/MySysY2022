	.attribute	4, 16
	.attribute	5, "rv64i2p1_m2p0_a2p1_f2p2_d2p2_c2p0_zicsr2p0_zmmul1p0_zaamo1p0_zalrsc1p0_zca1p0_zcd1p0"
	.file	"sysy_module"
	.text
	.globl	sum_row
	.p2align	1
	.type	sum_row,@function
sum_row:
	sext.w	a2, a1
	blez	a2, .LBB0_4
	li	a2, 0
	addi	a1, a1, -1
	slli	a1, a1, 32
	srli	a1, a1, 30
	add	a1, a1, a0
	addi	a1, a1, 4
.LBB0_2:
	lw	a3, 0(a0)
	addi	a0, a0, 4
	addw	a2, a2, a3
	bne	a0, a1, .LBB0_2
	mv	a0, a2
	ret
.LBB0_4:
	li	a0, 0
	ret
.Lfunc_end0:
	.size	sum_row, .Lfunc_end0-sum_row

	.globl	side_effect
	.p2align	1
	.type	side_effect,@function
side_effect:
	lui	a1, %hi(call_count)
	lw	a2, %lo(call_count)(a1)
	add	a2, a2, a0
	li	a0, 100
	sw	a2, %lo(call_count)(a1)
	ret
.Lfunc_end1:
	.size	side_effect, .Lfunc_end1-side_effect

	.globl	__sysy_main
	.p2align	1
	.type	__sysy_main,@function
__sysy_main:
	.cfi_startproc
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sd	ra, 8(sp)
	.cfi_offset ra, -8
	li	a0, 33
	call	putint
	li	a0, 10
	call	putch
	li	a0, 35
	call	putint
	li	a0, 10
	call	putch
	li	a0, 15
	call	putint
	li	a0, 10
	call	putch
	lui	a0, %hi(call_count)
	sw	zero, %lo(call_count)(a0)
	li	a0, 42
	call	putint
	li	a0, 10
	call	putch
	li	a0, 12
	call	putint
	li	a0, 10
	call	putch
	li	a0, 0
	ld	ra, 8(sp)
	.cfi_restore ra
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end2:
	.size	__sysy_main, .Lfunc_end2-__sysy_main
	.cfi_endproc

	.globl	main
	.p2align	1
	.type	main,@function
main:
	.cfi_startproc
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sd	ra, 8(sp)
	.cfi_offset ra, -8
	li	a0, 33
	call	putint
	li	a0, 10
	call	putch
	li	a0, 35
	call	putint
	li	a0, 10
	call	putch
	li	a0, 15
	call	putint
	li	a0, 10
	call	putch
	lui	a0, %hi(call_count)
	sw	zero, %lo(call_count)(a0)
	li	a0, 42
	call	putint
	li	a0, 10
	call	putch
	li	a0, 12
	call	putint
	li	a0, 10
	call	putch
	li	a0, 0
	call	putint
	li	a0, 10
	call	putch
	li	a0, 0
	ld	ra, 8(sp)
	.cfi_restore ra
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end3:
	.size	main, .Lfunc_end3-main
	.cfi_endproc

	.type	BASE,@object
	.section	.rodata,"a",@progbits
	.globl	BASE
	.p2align	2, 0x0
BASE:
	.word	2
	.size	BASE, 4

	.type	SIZE,@object
	.globl	SIZE
	.p2align	2, 0x0
SIZE:
	.word	5
	.size	SIZE, 4

	.type	MAT,@object
	.globl	MAT
	.p2align	2, 0x0
MAT:
	.word	1
	.word	2
	.word	3
	.word	4
	.size	MAT, 16

	.type	DIM,@object
	.globl	DIM
	.p2align	2, 0x0
DIM:
	.word	3
	.size	DIM, 4

	.type	A,@object
	.globl	A
	.p2align	2, 0x0
A:
	.word	10
	.size	A, 4

	.type	B,@object
	.globl	B
	.p2align	2, 0x0
B:
	.word	20
	.size	B, 4

	.type	ARR,@object
	.globl	ARR
	.p2align	4, 0x0
ARR:
	.word	10
	.word	20
	.word	30
	.word	10
	.word	20
	.size	ARR, 20

	.type	call_count,@object
	.bss
	.globl	call_count
	.p2align	2, 0x0
call_count:
	.word	0
	.size	call_count, 4

	.section	".note.GNU-stack","",@progbits
