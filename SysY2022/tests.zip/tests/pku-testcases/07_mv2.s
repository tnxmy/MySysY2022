	.attribute	4, 16
	.attribute	5, "rv64i2p1_m2p0_a2p1_f2p2_d2p2_c2p0_zicsr2p0_zmmul1p0_zaamo1p0_zalrsc1p0_zca1p0_zcd1p0"
	.file	"sysy_module"
	.text
	.globl	mv
	.p2align	1
	.type	mv,@function
mv:
	addi	sp, sp, -64
	sd	ra, 56(sp)
	sd	s0, 48(sp)
	sd	s1, 40(sp)
	sd	s2, 32(sp)
	sd	s3, 24(sp)
	sd	s4, 16(sp)
	sd	s5, 8(sp)
	sd	s6, 0(sp)
	mv	s4, a3
	mv	s2, a2
	mv	s3, a0
	sext.w	s6, a0
	mv	s5, a1
	blez	s6, .LBB0_2
	slli	a2, s6, 2
	mv	a0, s4
	li	a1, 0
	call	memset
.LBB0_2:
	blez	s6, .LBB0_9
	li	t0, 0
	li	a1, 0
	addi	s3, s3, -1
	lui	a2, 2
	slli	s3, s3, 32
	srli	a6, s3, 30
	addi	a6, a6, 4
	addi	a7, a2, -152
	mv	t1, s5
	j	.LBB0_5
.LBB0_4:
	addiw	a2, a1, 1
	addi	a1, a1, 1
	add	t1, t1, a7
	addi	t0, t0, 1
	bge	a2, s6, .LBB0_9
.LBB0_5:
	mul	a2, t0, a7
	slli	s1, a1, 2
	add	a2, a2, a6
	add	a5, s5, a2
	add	s1, s1, s4
	mv	s0, s2
	mv	a4, t1
	j	.LBB0_7
.LBB0_6:
	addi	a4, a4, 4
	addi	s0, s0, 4
	beq	a4, a5, .LBB0_4
.LBB0_7:
	lw	a2, 0(a4)
	beqz	a2, .LBB0_6
	lw	a0, 0(s0)
	lw	a3, 0(s1)
	mul	a0, a0, a2
	add	a0, a0, a3
	sw	a0, 0(s1)
	j	.LBB0_6
.LBB0_9:
	ld	ra, 56(sp)
	ld	s0, 48(sp)
	ld	s1, 40(sp)
	ld	s2, 32(sp)
	ld	s3, 24(sp)
	ld	s4, 16(sp)
	ld	s5, 8(sp)
	ld	s6, 0(sp)
	addi	sp, sp, 64
	ret
.Lfunc_end0:
	.size	mv, .Lfunc_end0-mv

	.globl	__sysy_main
	.p2align	1
	.type	__sysy_main,@function
__sysy_main:
	.cfi_startproc
	addi	sp, sp, -112
	.cfi_def_cfa_offset 112
	sd	ra, 104(sp)
	sd	s0, 96(sp)
	sd	s1, 88(sp)
	sd	s2, 80(sp)
	sd	s3, 72(sp)
	sd	s4, 64(sp)
	sd	s5, 56(sp)
	sd	s6, 48(sp)
	sd	s7, 40(sp)
	sd	s8, 32(sp)
	sd	s9, 24(sp)
	sd	s10, 16(sp)
	sd	s11, 8(sp)
	.cfi_offset ra, -8
	.cfi_offset s0, -16
	.cfi_offset s1, -24
	.cfi_offset s2, -32
	.cfi_offset s3, -40
	.cfi_offset s4, -48
	.cfi_offset s5, -56
	.cfi_offset s6, -64
	.cfi_offset s7, -72
	.cfi_offset s8, -80
	.cfi_offset s9, -88
	.cfi_offset s10, -96
	.cfi_offset s11, -104
	lui	a0, 2
	addi	s6, a0, -152
	call	getint
	sext.w	s7, a0
	addi	s4, s7, -1
	blez	s7, .LBB1_5
	li	s5, 0
	li	s8, 0
	slli	a0, s4, 32
	srli	a0, a0, 30
	lui	s2, %hi(A)
	addi	s2, s2, %lo(A)
	addi	s3, a0, 4
	mv	s9, s2
.LBB1_2:
	mul	a0, s5, s6
	add	a0, a0, s3
	add	s0, s2, a0
	mv	s1, s9
.LBB1_3:
	call	getint
	sw	a0, 0(s1)
	addi	s1, s1, 4
	bne	s1, s0, .LBB1_3
	addiw	s8, s8, 1
	add	s9, s9, s6
	addi	s5, s5, 1
	blt	s8, s7, .LBB1_2
.LBB1_5:
	blez	s7, .LBB1_8
	slli	a0, s4, 32
	srli	a0, a0, 30
	lui	s0, %hi(B)
	addi	s0, s0, %lo(B)
	add	a0, a0, s0
	addi	s1, a0, 4
.LBB1_7:
	call	getint
	sw	a0, 0(s0)
	addi	s0, s0, 4
	bne	s0, s1, .LBB1_7
.LBB1_8:
	lui	s5, %hi(A)
	addi	s5, s5, %lo(A)
	lui	s3, %hi(B)
	addi	s3, s3, %lo(B)
	call	starttime
	li	a0, 0
	slli	s2, s7, 2
	slli	a1, s4, 32
	lui	s4, %hi(C)
	addi	s4, s4, %lo(C)
	lui	a2, 2
	srli	a1, a1, 30
	addi	s10, a2, -152
	addi	s11, a1, 4
	li	s8, 49
	j	.LBB1_10
.LBB1_9:
	addiw	a0, s9, 1
	bgeu	s9, s8, .LBB1_23
.LBB1_10:
	mv	s9, a0
	blez	s7, .LBB1_9
	mv	a0, s4
	li	a1, 0
	mv	a2, s2
	call	memset
	li	a6, 0
	li	a2, 0
	mv	a7, s5
	j	.LBB1_13
.LBB1_12:
	addiw	a3, a2, 1
	addi	a2, a2, 1
	add	a7, a7, s10
	addi	a6, a6, 1
	bge	a3, s7, .LBB1_17
.LBB1_13:
	mul	a3, a6, s6
	slli	a4, a2, 2
	add	a3, a3, s11
	add	a3, a3, s5
	add	a4, a4, s4
	mv	a5, a7
	mv	s1, s3
	j	.LBB1_15
.LBB1_14:
	addi	a5, a5, 4
	addi	s1, s1, 4
	beq	a5, a3, .LBB1_12
.LBB1_15:
	lw	s0, 0(a5)
	beqz	s0, .LBB1_14
	lw	a0, 0(s1)
	lw	a1, 0(a4)
	mul	a0, a0, s0
	add	a0, a0, a1
	sw	a0, 0(a4)
	j	.LBB1_14
.LBB1_17:
	mv	a0, s3
	li	a1, 0
	mv	a2, s2
	call	memset
	li	a6, 0
	li	a2, 0
	mv	a7, s5
	j	.LBB1_19
.LBB1_18:
	addiw	a3, a2, 1
	addi	a2, a2, 1
	add	a7, a7, s10
	addi	a6, a6, 1
	bge	a3, s7, .LBB1_9
.LBB1_19:
	mul	a3, a6, s6
	slli	a4, a2, 2
	add	a3, a3, s11
	add	a3, a3, s5
	add	a4, a4, s3
	mv	a5, a7
	mv	s1, s4
	j	.LBB1_21
.LBB1_20:
	addi	a5, a5, 4
	addi	s1, s1, 4
	beq	a5, a3, .LBB1_18
.LBB1_21:
	lw	s0, 0(a5)
	beqz	s0, .LBB1_20
	lw	a0, 0(s1)
	lw	a1, 0(a4)
	mul	a0, a0, s0
	add	a0, a0, a1
	sw	a0, 0(a4)
	j	.LBB1_20
.LBB1_23:
	call	stoptime
	lui	a1, %hi(C)
	addi	a1, a1, %lo(C)
	mv	a0, s7
	call	putarray
	li	a0, 0
	ld	ra, 104(sp)
	ld	s0, 96(sp)
	ld	s1, 88(sp)
	ld	s2, 80(sp)
	ld	s3, 72(sp)
	ld	s4, 64(sp)
	ld	s5, 56(sp)
	ld	s6, 48(sp)
	ld	s7, 40(sp)
	ld	s8, 32(sp)
	ld	s9, 24(sp)
	ld	s10, 16(sp)
	ld	s11, 8(sp)
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	.cfi_restore s3
	.cfi_restore s4
	.cfi_restore s5
	.cfi_restore s6
	.cfi_restore s7
	.cfi_restore s8
	.cfi_restore s9
	.cfi_restore s10
	.cfi_restore s11
	addi	sp, sp, 112
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end1:
	.size	__sysy_main, .Lfunc_end1-__sysy_main
	.cfi_endproc

	.globl	main
	.p2align	1
	.type	main,@function
main:
	.cfi_startproc
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sd	ra, 8(sp)
	.cfi_offset ra, -8
	call	__sysy_main
	li	a0, 0
	call	putint
	li	a0, 10
	call	putch
	li	a0, 0
	ld	ra, 8(sp)
	.cfi_restore ra
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end2:
	.size	main, .Lfunc_end2-main
	.cfi_endproc

	.type	x,@object
	.bss
	.globl	x
	.p2align	2, 0x0
x:
	.word	0
	.size	x, 4

	.type	N,@object
	.section	.rodata,"a",@progbits
	.globl	N
	.p2align	2, 0x0
N:
	.word	2010
	.size	N, 4

	.type	A,@object
	.bss
	.globl	A
	.p2align	4, 0x0
A:
	.zero	16160400
	.size	A, 16160400

	.type	B,@object
	.globl	B
	.p2align	4, 0x0
B:
	.zero	8040
	.size	B, 8040

	.type	C,@object
	.globl	C
	.p2align	4, 0x0
C:
	.zero	8040
	.size	C, 8040

	.section	".note.GNU-stack","",@progbits
