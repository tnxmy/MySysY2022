	.attribute	4, 16
	.attribute	5, "rv64i2p1_m2p0_a2p1_f2p2_d2p2_c2p0_zicsr2p0_zmmul1p0_zaamo1p0_zalrsc1p0_zca1p0_zcd1p0"
	.file	"sysy_module"
	.text
	.globl	transpose
	.p2align	1
	.type	transpose,@function
transpose:
	divw	a7, a0, a2
	blez	a7, .LBB0_8
	li	a6, 0
	li	t1, 0
	sext.w	t0, a2
	j	.LBB0_3
.LBB0_2:
	addiw	t1, t1, 1
	add	a6, a6, a2
	bge	t1, a7, .LBB0_8
.LBB0_3:
	blez	t0, .LBB0_2
	li	a3, 0
	mv	a0, t1
	j	.LBB0_6
.LBB0_5:
	addiw	a3, a3, 1
	addw	a0, a0, a7
	bge	a3, t0, .LBB0_2
.LBB0_6:
	bltu	t1, a3, .LBB0_5
	addw	a5, a6, a3
	slli	a5, a5, 2
	add	t2, a1, a5
	lw	a5, 0(t2)
	slli	a4, a0, 2
	add	a4, a4, a1
	sw	a5, 0(a4)
	sw	a5, 0(t2)
	j	.LBB0_5
.LBB0_8:
	li	a0, -1
	ret
.Lfunc_end0:
	.size	transpose, .Lfunc_end0-transpose

	.globl	__sysy_main
	.p2align	1
	.type	__sysy_main,@function
__sysy_main:
	.cfi_startproc
	addi	sp, sp, -48
	.cfi_def_cfa_offset 48
	sd	ra, 40(sp)
	sd	s0, 32(sp)
	sd	s1, 24(sp)
	sd	s2, 16(sp)
	sd	s3, 8(sp)
	sd	s4, 0(sp)
	.cfi_offset ra, -8
	.cfi_offset s0, -16
	.cfi_offset s1, -24
	.cfi_offset s2, -32
	.cfi_offset s3, -40
	.cfi_offset s4, -48
	call	getint
	sext.w	s4, a0
	lui	s2, %hi(a)
	addi	s2, s2, %lo(a)
	mv	a0, s2
	call	getarray
	sext.w	s3, a0
	call	starttime
	blez	s4, .LBB1_3
	li	a0, 0
	lui	a1, %hi(matrix)
	addi	a1, a1, %lo(matrix)
.LBB1_2:
	sw	a0, 0(a1)
	addiw	a0, a0, 1
	addi	a1, a1, 4
	blt	a0, s4, .LBB1_2
.LBB1_3:
	blez	s3, .LBB1_14
	li	a6, 0
	lui	a7, %hi(matrix)
	addi	a7, a7, %lo(matrix)
	j	.LBB1_6
.LBB1_5:
	addiw	a0, a6, 1
	addi	a6, a6, 1
	bge	a0, s3, .LBB1_14
.LBB1_6:
	slli	a2, a6, 2
	add	a2, a2, s2
	lw	a2, 0(a2)
	divw	a3, s4, a2
	blez	a3, .LBB1_5
	li	t0, 0
	li	a0, 0
	j	.LBB1_9
.LBB1_8:
	addiw	a0, a0, 1
	add	t0, t0, a2
	bge	a0, a3, .LBB1_5
.LBB1_9:
	blez	a2, .LBB1_8
	li	s1, 0
	mv	s0, a0
	j	.LBB1_12
.LBB1_11:
	addiw	s1, s1, 1
	addw	s0, s0, a3
	bge	s1, a2, .LBB1_8
.LBB1_12:
	bltu	a0, s1, .LBB1_11
	addw	a4, t0, s1
	slli	a4, a4, 2
	add	a4, a4, a7
	lw	a1, 0(a4)
	slli	a5, s0, 2
	add	a5, a5, a7
	sw	a1, 0(a5)
	sw	a1, 0(a4)
	j	.LBB1_11
.LBB1_14:
	blez	s3, .LBB1_17
	li	a1, 0
	li	a0, 0
	lui	a2, %hi(matrix)
	addi	a2, a2, %lo(matrix)
.LBB1_16:
	lw	a3, 0(a2)
	mul	a4, a1, a1
	addiw	a1, a1, 1
	mul	a3, a4, a3
	add	a0, a0, a3
	addi	a2, a2, 4
	blt	a1, s3, .LBB1_16
	j	.LBB1_18
.LBB1_17:
	li	a0, 0
.LBB1_18:
	sraiw	a1, a0, 31
	xor	a0, a0, a1
	subw	s0, a0, a1
	call	stoptime
	mv	a0, s0
	call	putint
	li	a0, 10
	call	putch
	li	a0, 0
	ld	ra, 40(sp)
	ld	s0, 32(sp)
	ld	s1, 24(sp)
	ld	s2, 16(sp)
	ld	s3, 8(sp)
	ld	s4, 0(sp)
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	.cfi_restore s3
	.cfi_restore s4
	addi	sp, sp, 48
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end1:
	.size	__sysy_main, .Lfunc_end1-__sysy_main
	.cfi_endproc

	.globl	main
	.p2align	1
	.type	main,@function
main:
	.cfi_startproc
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sd	ra, 8(sp)
	.cfi_offset ra, -8
	call	__sysy_main
	li	a0, 0
	call	putint
	li	a0, 10
	call	putch
	li	a0, 0
	ld	ra, 8(sp)
	.cfi_restore ra
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end2:
	.size	main, .Lfunc_end2-main
	.cfi_endproc

	.type	matrix,@object
	.bss
	.globl	matrix
	.p2align	4, 0x0
matrix:
	.zero	80000000
	.size	matrix, 80000000

	.type	a,@object
	.globl	a
	.p2align	4, 0x0
a:
	.zero	400000
	.size	a, 400000

	.section	".note.GNU-stack","",@progbits
