	.attribute	4, 16
	.attribute	5, "rv64i2p1_m2p0_a2p1_f2p2_d2p2_c2p0_zicsr2p0_zmmul1p0_zaamo1p0_zalrsc1p0_zca1p0_zcd1p0"
	.file	"sysy_module"
	.text
	.globl	set
	.p2align	1
	.type	set,@function
set:
	addi	sp, sp, -256
	sd	ra, 248(sp)
	sd	s0, 240(sp)
	sd	s1, 232(sp)
	sd	s2, 224(sp)
	sd	s3, 216(sp)
	sd	s4, 208(sp)
	sd	s5, 200(sp)
	sd	s6, 192(sp)
	sd	s7, 184(sp)
	sd	s8, 176(sp)
	sd	s9, 168(sp)
	sd	s10, 160(sp)
	sd	s11, 152(sp)
	sd	a2, 16(sp)
	mv	s2, a1
	sd	a0, 8(sp)
	sext.w	s4, a1
	addi	a0, sp, 28
	li	a2, 124
	li	a1, 0
	call	memset
	li	t1, 1
	li	t2, 2
	li	t4, 4
	li	t5, 8
	li	t3, 16
	li	t6, 32
	li	s5, 64
	li	s6, 128
	li	a6, 256
	li	a7, 512
	li	t0, 1024
	lui	s7, 1
	lui	s8, 2
	lui	s10, 4
	lui	s11, 8
	lui	s9, 16
	lui	ra, 32
	lui	a2, 64
	lui	a5, 128
	lui	a0, 256
	lui	a1, 512
	lui	a3, 1024
	lui	a4, 2048
	lui	s3, 4096
	sw	t1, 28(sp)
	sw	t2, 32(sp)
	sw	t4, 36(sp)
	sw	t5, 40(sp)
	lui	t2, 8192
	sw	t3, 44(sp)
	sw	t6, 48(sp)
	sw	s5, 52(sp)
	sw	s6, 56(sp)
	lui	s0, 16384
	sw	s7, 76(sp)
	sw	s8, 80(sp)
	sw	s10, 84(sp)
	sw	s11, 88(sp)
	lui	s1, 32768
	sw	s9, 92(sp)
	sw	ra, 96(sp)
	sw	a2, 100(sp)
	sw	a5, 104(sp)
	lui	a2, 65536
	sw	a0, 108(sp)
	sw	a1, 112(sp)
	sw	a3, 116(sp)
	sw	a4, 120(sp)
	lui	a0, 131072
	sw	s3, 124(sp)
	sw	t2, 128(sp)
	sw	s0, 132(sp)
	sw	s1, 136(sp)
	lui	a1, 262144
	sw	a2, 140(sp)
	sw	a0, 144(sp)
	sw	a1, 148(sp)
	lui	a0, 73
	slli	t1, t1, 11
	addi	a0, a0, 992
	sw	a6, 60(sp)
	sw	a7, 64(sp)
	sw	t0, 68(sp)
	sw	t1, 72(sp)
	sw	zero, 24(sp)
	bge	s4, a0, .LBB0_9
	lui	a0, 559241
	addi	a0, a0, -1911
	mul	a0, s4, a0
	srli	a0, a0, 32
	add	a0, a0, s2
	srliw	a1, a0, 31
	sraiw	a0, a0, 4
	addw	a0, a0, a1
	slli	s4, a0, 2
	slli	a1, a0, 5
	slli	a0, a0, 1
	ld	a2, 8(sp)
	add	s4, s4, a2
	subw	a1, a0, a1
	lw	a0, 0(s4)
	addw	a1, s2, a1
	slli	a1, a1, 2
	addi	a2, sp, 28
	add	a1, a1, a2
	lw	a1, 0(a1)
	divw	a2, a0, a1
	srliw	a3, a2, 31
	add	a3, a3, a2
	andi	a3, a3, -2
	subw	a3, a2, a3
	lw	s2, 16(sp)
	beq	a3, s2, .LBB0_8
	bnez	a3, .LBB0_5
	li	a3, 1
	bne	s2, a3, .LBB0_5
	sw	a1, 24(sp)
.LBB0_5:
	lui	a3, 524288
	addi	a3, a3, 1
	and	a2, a2, a3
	li	a3, 1
	bne	a2, a3, .LBB0_8
	bnez	s2, .LBB0_8
	lw	a2, 24(sp)
	subw	a2, a2, a1
	sw	a2, 24(sp)
.LBB0_8:
	lw	a1, 24(sp)
	add	a0, a0, a1
	sw	a0, 0(s4)
.LBB0_9:
	li	a0, 0
	ld	ra, 248(sp)
	ld	s0, 240(sp)
	ld	s1, 232(sp)
	ld	s2, 224(sp)
	ld	s3, 216(sp)
	ld	s4, 208(sp)
	ld	s5, 200(sp)
	ld	s6, 192(sp)
	ld	s7, 184(sp)
	ld	s8, 176(sp)
	ld	s9, 168(sp)
	ld	s10, 160(sp)
	ld	s11, 152(sp)
	addi	sp, sp, 256
	ret
.Lfunc_end0:
	.size	set, .Lfunc_end0-set

	.globl	rand
	.p2align	1
	.type	rand,@function
rand:
	lui	a1, %hi(staticvalue)
	lui	a0, %hi(seed)
	lw	a2, %lo(staticvalue)(a1)
	addi	a3, a0, %lo(seed)
	lw	a0, %lo(seed)(a0)
	lw	a4, 4(a3)
	lw	a3, 8(a3)
	mul	a0, a0, a2
	add	a0, a0, a4
	remw	a0, a0, a3
	srli	a2, a0, 31
	and	a2, a2, a3
	addw	a0, a0, a2
	sw	a0, %lo(staticvalue)(a1)
	ret
.Lfunc_end1:
	.size	rand, .Lfunc_end1-rand

	.globl	__sysy_main
	.p2align	1
	.type	__sysy_main,@function
__sysy_main:
	.cfi_startproc
	addi	sp, sp, -96
	.cfi_def_cfa_offset 96
	sd	ra, 88(sp)
	sd	s0, 80(sp)
	sd	s1, 72(sp)
	sd	s2, 64(sp)
	sd	s3, 56(sp)
	sd	s4, 48(sp)
	sd	s5, 40(sp)
	sd	s6, 32(sp)
	sd	s7, 24(sp)
	sd	s8, 16(sp)
	sd	s9, 8(sp)
	.cfi_offset ra, -8
	.cfi_offset s0, -16
	.cfi_offset s1, -24
	.cfi_offset s2, -32
	.cfi_offset s3, -40
	.cfi_offset s4, -48
	.cfi_offset s5, -56
	.cfi_offset s6, -64
	.cfi_offset s7, -72
	.cfi_offset s8, -80
	.cfi_offset s9, -88
	call	getint
	sext.w	s1, a0
	call	getint
	lui	s2, %hi(staticvalue)
	sw	a0, %lo(staticvalue)(s2)
	call	starttime
	blez	s1, .LBB2_3
	lw	s0, %lo(staticvalue)(s2)
	lui	a0, %hi(seed)
	addi	s1, s1, 1
	lui	a1, 458130
	lw	s5, %lo(seed)(a0)
	addi	a0, a0, %lo(seed)
	addi	s4, a1, -635
	lw	s6, 4(a0)
	lw	s9, 8(a0)
	lui	a0, 73
	addi	s7, a0, 992
	lui	s3, %hi(a)
	addi	s3, s3, %lo(a)
	li	s8, 1
.LBB2_2:
	mul	a0, s5, s0
	add	a0, a0, s6
	remw	a0, a0, s9
	srai	a1, a0, 31
	and	a1, a1, s9
	addw	a0, a0, a1
	mul	a1, a0, s5
	add	a1, a1, s6
	remw	s0, a1, s9
	mul	a1, a0, s4
	srli	a2, a1, 63
	srai	a1, a1, 49
	add	a1, a1, a2
	mul	a1, a1, s7
	subw	a1, a0, a1
	srli	a0, s0, 31
	and	a0, a0, s9
	add	s0, s0, a0
	sw	s0, %lo(staticvalue)(s2)
	srliw	a0, s0, 31
	add	a0, a0, s0
	andi	a0, a0, -2
	subw	a2, s0, a0
	mv	a0, s3
	call	set
	addiw	s1, s1, -1
	blt	s8, s1, .LBB2_2
.LBB2_3:
	call	stoptime
	lui	a1, %hi(a)
	addi	a1, a1, %lo(a)
	lui	a0, 2
	addi	a0, a0, 1808
	call	putarray
	li	a0, 0
	ld	ra, 88(sp)
	ld	s0, 80(sp)
	ld	s1, 72(sp)
	ld	s2, 64(sp)
	ld	s3, 56(sp)
	ld	s4, 48(sp)
	ld	s5, 40(sp)
	ld	s6, 32(sp)
	ld	s7, 24(sp)
	ld	s8, 16(sp)
	ld	s9, 8(sp)
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	.cfi_restore s3
	.cfi_restore s4
	.cfi_restore s5
	.cfi_restore s6
	.cfi_restore s7
	.cfi_restore s8
	.cfi_restore s9
	addi	sp, sp, 96
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end2:
	.size	__sysy_main, .Lfunc_end2-__sysy_main
	.cfi_endproc

	.globl	main
	.p2align	1
	.type	main,@function
main:
	.cfi_startproc
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sd	ra, 8(sp)
	.cfi_offset ra, -8
	call	__sysy_main
	li	a0, 0
	call	putint
	li	a0, 10
	call	putch
	li	a0, 0
	ld	ra, 8(sp)
	.cfi_restore ra
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end3:
	.size	main, .Lfunc_end3-main
	.cfi_endproc

	.type	seed,@object
	.data
	.globl	seed
	.p2align	2, 0x0
seed:
	.word	19971231
	.word	19981013
	.word	0
	.size	seed, 12

	.type	staticvalue,@object
	.bss
	.globl	staticvalue
	.p2align	2, 0x0
staticvalue:
	.word	0
	.size	staticvalue, 4

	.type	a,@object
	.globl	a
	.p2align	4, 0x0
a:
	.zero	40000
	.size	a, 40000

	.section	".note.GNU-stack","",@progbits
