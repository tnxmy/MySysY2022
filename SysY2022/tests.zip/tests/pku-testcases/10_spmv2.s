	.attribute	4, 16
	.attribute	5, "rv64i2p1_m2p0_a2p1_f2p2_d2p2_c2p0_zicsr2p0_zmmul1p0_zaamo1p0_zalrsc1p0_zca1p0_zcd1p0"
	.file	"sysy_module"
	.text
	.globl	spmv
	.p2align	1
	.type	spmv,@function
spmv:
	addi	sp, sp, -80
	sd	ra, 72(sp)
	sd	s0, 64(sp)
	sd	s1, 56(sp)
	sd	s2, 48(sp)
	sd	s3, 40(sp)
	sd	s4, 32(sp)
	sd	s5, 24(sp)
	sd	s6, 16(sp)
	sd	s7, 8(sp)
	mv	s7, a5
	mv	s2, a4
	mv	s3, a3
	mv	s4, a2
	sext.w	s5, a0
	mv	s6, a1
	blez	s5, .LBB0_2
	slli	a2, s5, 2
	mv	a0, s7
	li	a1, 0
	call	memset
.LBB0_2:
	blez	s5, .LBB0_11
	li	a7, 0
	j	.LBB0_5
.LBB0_4:
	sext.w	a1, a7
	bge	a1, s5, .LBB0_11
.LBB0_5:
	slli	a6, a7, 2
	addi	a7, a7, 1
	add	t0, s6, a6
	slli	a1, a7, 2
	add	a1, a1, s6
	lw	a4, 0(t0)
	lw	a5, 0(a1)
	bge	a4, a5, .LBB0_8
	slli	s1, a4, 2
	add	a5, s3, s1
	add	s1, s1, s4
.LBB0_7:
	lw	a2, 0(s1)
	slli	a2, a2, 2
	add	a2, a2, s7
	lw	a0, 0(a2)
	lw	a3, 0(a5)
	add	a0, a0, a3
	sw	a0, 0(a2)
	lw	a0, 0(a1)
	addiw	a4, a4, 1
	addi	a5, a5, 4
	addi	s1, s1, 4
	blt	a4, a0, .LBB0_7
.LBB0_8:
	lw	a3, 0(t0)
	lw	a0, 0(a1)
	bge	a3, a0, .LBB0_4
	add	a6, a6, s2
	slli	a5, a3, 2
	add	a4, s3, a5
	add	a5, a5, s4
.LBB0_10:
	lw	a0, 0(a5)
	lw	s1, 0(a6)
	slli	a0, a0, 2
	add	a0, a0, s7
	lw	s0, 0(a4)
	lw	a2, 0(a0)
	addi	s1, s1, -1
	mul	s1, s1, s0
	add	a2, a2, s1
	sw	a2, 0(a0)
	lw	a0, 0(a1)
	addiw	a3, a3, 1
	addi	a4, a4, 4
	addi	a5, a5, 4
	blt	a3, a0, .LBB0_10
	j	.LBB0_4
.LBB0_11:
	ld	ra, 72(sp)
	ld	s0, 64(sp)
	ld	s1, 56(sp)
	ld	s2, 48(sp)
	ld	s3, 40(sp)
	ld	s4, 32(sp)
	ld	s5, 24(sp)
	ld	s6, 16(sp)
	ld	s7, 8(sp)
	addi	sp, sp, 80
	ret
.Lfunc_end0:
	.size	spmv, .Lfunc_end0-spmv

	.globl	__sysy_main
	.p2align	1
	.type	__sysy_main,@function
__sysy_main:
	.cfi_startproc
	addi	sp, sp, -96
	.cfi_def_cfa_offset 96
	sd	ra, 88(sp)
	sd	s0, 80(sp)
	sd	s1, 72(sp)
	sd	s2, 64(sp)
	sd	s3, 56(sp)
	sd	s4, 48(sp)
	sd	s5, 40(sp)
	sd	s6, 32(sp)
	sd	s7, 24(sp)
	sd	s8, 16(sp)
	sd	s9, 8(sp)
	sd	s10, 0(sp)
	.cfi_offset ra, -8
	.cfi_offset s0, -16
	.cfi_offset s1, -24
	.cfi_offset s2, -32
	.cfi_offset s3, -40
	.cfi_offset s4, -48
	.cfi_offset s5, -56
	.cfi_offset s6, -64
	.cfi_offset s7, -72
	.cfi_offset s8, -80
	.cfi_offset s9, -88
	.cfi_offset s10, -96
	lui	s4, %hi(x)
	addi	s4, s4, %lo(x)
	mv	a0, s4
	call	getarray
	addiw	s6, a0, -1
	lui	s2, %hi(y)
	addi	s2, s2, %lo(y)
	mv	a0, s2
	call	getarray
	lui	s3, %hi(v)
	addi	s3, s3, %lo(v)
	mv	a0, s3
	call	getarray
	lui	s9, %hi(a)
	addi	s9, s9, %lo(a)
	mv	a0, s9
	call	getarray
	call	starttime
	li	a0, 0
	slli	s5, s6, 2
	lui	s10, %hi(b)
	addi	s10, s10, %lo(b)
	li	s7, 99
	j	.LBB1_2
.LBB1_1:
	addiw	a0, s8, 1
	bgeu	s8, s7, .LBB1_17
.LBB1_2:
	mv	s8, a0
	blez	s6, .LBB1_1
	mv	a0, s10
	li	a1, 0
	mv	a2, s5
	call	memset
	li	a6, 0
	j	.LBB1_5
.LBB1_4:
	sext.w	a0, a6
	bge	a0, s6, .LBB1_10
.LBB1_5:
	slli	a7, a6, 2
	addi	a6, a6, 1
	add	a0, s4, a7
	slli	a1, a6, 2
	add	a1, a1, s4
	lw	a0, 0(a0)
	lw	a1, 0(a1)
	bge	a0, a1, .LBB1_4
	slli	a3, a0, 2
	not	a5, a0
	add	a0, s3, a3
	add	a2, s2, a3
	add	a1, a1, a5
	slli	a1, a1, 32
	srli	a1, a1, 30
	add	a3, a3, s3
	add	a1, a1, a3
	addi	a3, a1, 4
	mv	a5, a2
	mv	a1, a0
.LBB1_7:
	lw	a4, 0(a5)
	lw	s1, 0(a1)
	slli	a4, a4, 2
	add	a4, a4, s10
	lw	s0, 0(a4)
	addi	a1, a1, 4
	add	s0, s0, s1
	sw	s0, 0(a4)
	addi	a5, a5, 4
	bne	a1, a3, .LBB1_7
	add	a7, a7, s9
	lw	a4, 0(a7)
	addi	a4, a4, -1
.LBB1_9:
	lw	a1, 0(a2)
	lw	a5, 0(a0)
	slli	a1, a1, 2
	add	a1, a1, s10
	lw	s1, 0(a1)
	addi	a0, a0, 4
	mul	a5, a4, a5
	add	a5, a5, s1
	sw	a5, 0(a1)
	addi	a2, a2, 4
	bne	a0, a3, .LBB1_9
	j	.LBB1_4
.LBB1_10:
	mv	a0, s9
	li	a1, 0
	mv	a2, s5
	call	memset
	li	a6, 0
	j	.LBB1_12
.LBB1_11:
	sext.w	a0, a6
	bge	a0, s6, .LBB1_1
.LBB1_12:
	slli	a7, a6, 2
	addi	a6, a6, 1
	add	a0, s4, a7
	slli	a1, a6, 2
	add	a1, a1, s4
	lw	a0, 0(a0)
	lw	a1, 0(a1)
	bge	a0, a1, .LBB1_11
	slli	a3, a0, 2
	not	a5, a0
	add	a0, s3, a3
	add	a2, s2, a3
	add	a1, a1, a5
	slli	a1, a1, 32
	srli	a1, a1, 30
	add	a3, a3, s3
	add	a1, a1, a3
	addi	a3, a1, 4
	mv	a5, a2
	mv	a1, a0
.LBB1_14:
	lw	s1, 0(a5)
	lw	s0, 0(a1)
	slli	s1, s1, 2
	add	s1, s1, s9
	lw	a4, 0(s1)
	addi	a1, a1, 4
	add	a4, a4, s0
	sw	a4, 0(s1)
	addi	a5, a5, 4
	bne	a1, a3, .LBB1_14
	add	a7, a7, s10
	lw	a4, 0(a7)
	addi	a4, a4, -1
.LBB1_16:
	lw	a1, 0(a2)
	lw	a5, 0(a0)
	slli	a1, a1, 2
	add	a1, a1, s9
	lw	s1, 0(a1)
	addi	a0, a0, 4
	mul	a5, a4, a5
	add	a5, a5, s1
	sw	a5, 0(a1)
	addi	a2, a2, 4
	bne	a0, a3, .LBB1_16
	j	.LBB1_11
.LBB1_17:
	call	stoptime
	lui	a1, %hi(b)
	addi	a1, a1, %lo(b)
	mv	a0, s6
	call	putarray
	li	a0, 0
	ld	ra, 88(sp)
	ld	s0, 80(sp)
	ld	s1, 72(sp)
	ld	s2, 64(sp)
	ld	s3, 56(sp)
	ld	s4, 48(sp)
	ld	s5, 40(sp)
	ld	s6, 32(sp)
	ld	s7, 24(sp)
	ld	s8, 16(sp)
	ld	s9, 8(sp)
	ld	s10, 0(sp)
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	.cfi_restore s3
	.cfi_restore s4
	.cfi_restore s5
	.cfi_restore s6
	.cfi_restore s7
	.cfi_restore s8
	.cfi_restore s9
	.cfi_restore s10
	addi	sp, sp, 96
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end1:
	.size	__sysy_main, .Lfunc_end1-__sysy_main
	.cfi_endproc

	.globl	main
	.p2align	1
	.type	main,@function
main:
	.cfi_startproc
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sd	ra, 8(sp)
	.cfi_offset ra, -8
	call	__sysy_main
	li	a0, 0
	call	putint
	li	a0, 10
	call	putch
	li	a0, 0
	ld	ra, 8(sp)
	.cfi_restore ra
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end2:
	.size	main, .Lfunc_end2-main
	.cfi_endproc

	.type	N,@object
	.section	.rodata,"a",@progbits
	.globl	N
	.p2align	2, 0x0
N:
	.word	100010
	.size	N, 4

	.type	M,@object
	.globl	M
	.p2align	2, 0x0
M:
	.word	3000000
	.size	M, 4

	.type	x,@object
	.bss
	.globl	x
	.p2align	4, 0x0
x:
	.zero	400040
	.size	x, 400040

	.type	y,@object
	.globl	y
	.p2align	4, 0x0
y:
	.zero	12000000
	.size	y, 12000000

	.type	v,@object
	.globl	v
	.p2align	4, 0x0
v:
	.zero	12000000
	.size	v, 12000000

	.type	a,@object
	.globl	a
	.p2align	4, 0x0
a:
	.zero	400040
	.size	a, 400040

	.type	b,@object
	.globl	b
	.p2align	4, 0x0
b:
	.zero	400040
	.size	b, 400040

	.type	c,@object
	.globl	c
	.p2align	4, 0x0
c:
	.zero	400040
	.size	c, 400040

	.section	".note.GNU-stack","",@progbits
