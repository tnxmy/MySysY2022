	.attribute	4, 16
	.attribute	5, "rv64i2p1_m2p0_a2p1_f2p2_d2p2_c2p0_zicsr2p0_zmmul1p0_zaamo1p0_zalrsc1p0_zca1p0_zcd1p0"
	.file	"sysy_module"
	.text
	.globl	multiply
	.p2align	1
	.type	multiply,@function
multiply:
	sext.w	a3, a1
	li	a2, 1
	beq	a3, a2, .LBB0_3
	mv	a2, a1
	bnez	a3, .LBB0_4
	mv	a0, a2
	ret
.LBB0_3:
	sext.w	a1, a0
	lui	a2, 70493
	addi	a2, a2, -2031
	mul	a1, a1, a2
	srli	a2, a1, 63
	srai	a1, a1, 58
	add	a1, a1, a2
	lui	a2, 243712
	addi	a2, a2, 1
	mul	a1, a1, a2
	subw	a0, a0, a1
	ret
.LBB0_4:
	addi	sp, sp, -32
	sd	ra, 24(sp)
	sd	s0, 16(sp)
	sd	s1, 8(sp)
	srliw	a2, a1, 31
	add	a2, a2, a1
	sraiw	a2, a2, 1
	mv	s0, a0
	mv	s1, a1
	mv	a1, a2
	call	multiply
	slliw	a2, a0, 1
	lui	a0, 70493
	lui	a3, 243712
	lui	a4, 524288
	addi	a1, a0, -2031
	addi	a0, a3, 1
	addi	a4, a4, 1
	mul	a3, a2, a1
	and	a4, a4, s1
	srli	a5, a3, 63
	srai	a3, a3, 58
	sext.w	a4, a4
	add	a3, a3, a5
	mul	a3, a3, a0
	li	a5, 1
	subw	a2, a2, a3
	bne	a4, a5, .LBB0_6
	addw	a2, a2, s0
	mul	a1, a2, a1
	srli	a3, a1, 63
	srai	a1, a1, 58
	add	a1, a1, a3
	mul	a0, a1, a0
	subw	a2, a2, a0
.LBB0_6:
	ld	ra, 24(sp)
	ld	s0, 16(sp)
	ld	s1, 8(sp)
	addi	sp, sp, 32
	mv	a0, a2
	ret
.Lfunc_end0:
	.size	multiply, .Lfunc_end0-multiply

	.globl	power
	.p2align	1
	.type	power,@function
power:
	addi	sp, sp, -32
	sd	ra, 24(sp)
	sd	s0, 16(sp)
	sd	s1, 8(sp)
	sext.w	a2, a1
	beqz	a2, .LBB1_3
	mv	s0, a0
	srliw	a0, a1, 31
	add	a0, a0, a1
	sraiw	a2, a0, 1
	mv	a0, s0
	mv	s1, a1
	mv	a1, a2
	call	power
	mv	a1, a0
	call	multiply
	lui	a1, 524288
	addi	a1, a1, 1
	and	a1, a1, s1
	sext.w	a1, a1
	li	a2, 1
	bne	a1, a2, .LBB1_4
	mv	a1, s0
	ld	ra, 24(sp)
	ld	s0, 16(sp)
	ld	s1, 8(sp)
	addi	sp, sp, 32
	tail	multiply
.LBB1_3:
	li	a0, 1
.LBB1_4:
	ld	ra, 24(sp)
	ld	s0, 16(sp)
	ld	s1, 8(sp)
	addi	sp, sp, 32
	ret
.Lfunc_end1:
	.size	power, .Lfunc_end1-power

	.globl	MemMove
	.p2align	1
	.type	MemMove,@function
MemMove:
	sext.w	a7, a3
	blez	a7, .LBB2_4
	mv	a6, a3
	li	a5, 0
.LBB2_2:
	addw	a3, a1, a5
	lw	a4, 0(a2)
	addiw	a5, a5, 1
	slli	a3, a3, 2
	add	a3, a3, a0
	sw	a4, 0(a3)
	addi	a2, a2, 4
	blt	a5, a7, .LBB2_2
	mv	a0, a6
	ret
.LBB2_4:
	li	a0, 0
	ret
.Lfunc_end2:
	.size	MemMove, .Lfunc_end2-MemMove

	.globl	fft
	.p2align	1
	.type	fft,@function
fft:
	addi	sp, sp, -112
	sd	ra, 104(sp)
	sd	s0, 96(sp)
	sd	s1, 88(sp)
	sd	s2, 80(sp)
	sd	s3, 72(sp)
	sd	s4, 64(sp)
	sd	s5, 56(sp)
	sd	s6, 48(sp)
	sd	s7, 40(sp)
	sd	s8, 32(sp)
	sd	s9, 24(sp)
	sd	s10, 16(sp)
	sd	s11, 8(sp)
	mv	s6, a1
	sext.w	s1, a2
	li	a1, 1
	beq	s1, a1, .LBB3_11
	mv	s2, a3
	mv	s7, a0
	blez	s1, .LBB3_4
	li	a0, 0
	srliw	a1, a2, 1
	lui	a6, %hi(temp)
	addi	a6, a6, %lo(temp)
	mv	a3, s6
.LBB3_3:
	slli	a5, a0, 63
	srliw	s0, a0, 1
	srai	a5, a5, 63
	and	a5, a5, a1
	addw	a5, a5, s0
	sext.w	a4, a3
	slli	a4, a4, 2
	add	a4, a4, s7
	lw	a4, 0(a4)
	addiw	a0, a0, 1
	slli	a5, a5, 2
	add	a5, a5, a6
	sw	a4, 0(a5)
	addi	a3, a3, 1
	blt	a0, s1, .LBB3_3
.LBB3_4:
	blez	s1, .LBB3_7
	li	a0, 0
	lui	a1, %hi(temp)
	addi	a1, a1, %lo(temp)
.LBB3_6:
	addw	a3, s6, a0
	lw	a4, 0(a1)
	addiw	a0, a0, 1
	slli	a3, a3, 2
	add	a3, a3, s7
	sw	a4, 0(a3)
	addi	a1, a1, 4
	blt	a0, s1, .LBB3_6
.LBB3_7:
	srliw	a0, a2, 31
	add	a0, a0, a2
	sraiw	s3, a0, 1
	mv	a0, s2
	mv	a1, s2
	call	multiply
	mv	s5, a0
	mv	a0, s7
	mv	a1, s6
	mv	a2, s3
	mv	a3, s5
	call	fft
	addw	s4, s3, s6
	mv	a0, s7
	mv	a1, s4
	mv	a2, s3
	mv	a3, s5
	call	fft
	li	a0, 2
	blt	s1, a0, .LBB3_10
	li	s0, 0
	li	s11, 1
	lui	a1, 70493
	lui	s8, 243712
	addi	s5, a1, -2031
	addi	s8, s8, 1
.LBB3_9:
	addw	a1, s6, s0
	addw	a2, s4, s0
	slli	a1, a1, 2
	slli	a2, a2, 2
	add	s9, s7, a1
	add	s10, s7, a2
	lw	s1, 0(s9)
	lw	a1, 0(s10)
	mv	a0, s11
	call	multiply
	addw	a1, a0, s1
	add	s1, s1, s8
	mul	a2, a1, s5
	subw	s1, s1, a0
	srli	a0, a2, 63
	srai	a2, a2, 58
	mul	a3, s1, s5
	add	a0, a0, a2
	srli	a2, a3, 63
	srai	a3, a3, 58
	mul	a0, a0, s8
	add	a2, a2, a3
	subw	a1, a1, a0
	mul	a0, a2, s8
	sw	a1, 0(s9)
	subw	s1, s1, a0
	sw	s1, 0(s10)
	mv	a0, s11
	mv	a1, s2
	call	multiply
	addiw	s0, s0, 1
	mv	s11, a0
	blt	s0, s3, .LBB3_9
.LBB3_10:
	li	a1, 0
.LBB3_11:
	mv	a0, a1
	ld	ra, 104(sp)
	ld	s0, 96(sp)
	ld	s1, 88(sp)
	ld	s2, 80(sp)
	ld	s3, 72(sp)
	ld	s4, 64(sp)
	ld	s5, 56(sp)
	ld	s6, 48(sp)
	ld	s7, 40(sp)
	ld	s8, 32(sp)
	ld	s9, 24(sp)
	ld	s10, 16(sp)
	ld	s11, 8(sp)
	addi	sp, sp, 112
	ret
.Lfunc_end3:
	.size	fft, .Lfunc_end3-fft

	.section	.rodata.cst32,"aM",@progbits,32
.LCPI4_0:
	.ascii	"\000\001\034\002\035\016\030\003\036\026\024\017\031\021\004\b\037\033\r\027\025\023\020\007\032\f\022\006\013\005\n\t"
	.text
	.globl	__sysy_main
	.p2align	1
	.type	__sysy_main,@function
__sysy_main:
	.cfi_startproc
	addi	sp, sp, -64
	.cfi_def_cfa_offset 64
	sd	ra, 56(sp)
	sd	s0, 48(sp)
	sd	s1, 40(sp)
	sd	s2, 32(sp)
	sd	s3, 24(sp)
	sd	s4, 16(sp)
	sd	s5, 8(sp)
	sd	s6, 0(sp)
	.cfi_offset ra, -8
	.cfi_offset s0, -16
	.cfi_offset s1, -24
	.cfi_offset s2, -32
	.cfi_offset s3, -40
	.cfi_offset s4, -48
	.cfi_offset s5, -56
	.cfi_offset s6, -64
	lui	a0, %hi(a)
	addi	a0, a0, %lo(a)
	call	getarray
	mv	s0, a0
	lui	a0, %hi(b)
	addi	a0, a0, %lo(b)
	call	getarray
	mv	s1, a0
	call	starttime
	add	s0, s0, s1
	addiw	s3, s0, -1
	li	a0, 1
.LBB4_1:
	mv	s0, a0
	slliw	a0, a0, 1
	blt	s0, s3, .LBB4_1
	negw	a0, s0
	lui	a1, 30667
	and	a0, a0, s0
	addi	a1, a1, 1329
	mul	a0, a0, a1
	srliw	a0, a0, 27
	lui	a1, %hi(.LCPI4_0)
	addi	a1, a1, %lo(.LCPI4_0)
	add	a0, a0, a1
	lbu	a0, 0(a0)
	lui	s4, %hi(d)
	sw	s0, %lo(d)(s4)
	lui	s5, 243712
	srlw	a1, s5, a0
	li	a0, 3
	call	power
	mv	a3, a0
	lui	s1, %hi(a)
	addi	s1, s1, %lo(a)
	mv	a0, s1
	li	a1, 0
	mv	a2, s0
	call	fft
	lw	s2, %lo(d)(s4)
	divw	a1, s5, s2
	li	a0, 3
	call	power
	mv	a3, a0
	lui	s0, %hi(b)
	addi	s0, s0, %lo(b)
	mv	a0, s0
	li	a1, 0
	mv	a2, s2
	call	fft
	lw	s2, %lo(d)(s4)
	blez	s2, .LBB4_5
	addi	a0, s2, -1
	slli	a0, a0, 32
	srli	a0, a0, 30
	add	a0, a0, s1
	addi	s6, a0, 4
.LBB4_4:
	lw	a1, 0(s0)
	lw	a0, 0(s1)
	call	multiply
	sw	a0, 0(s1)
	addi	s1, s1, 4
	addi	s0, s0, 4
	bne	s1, s6, .LBB4_4
.LBB4_5:
	divw	a0, s5, s2
	subw	a1, s5, a0
	li	a0, 3
	call	power
	mv	a3, a0
	lui	s1, %hi(a)
	addi	s1, s1, %lo(a)
	mv	a0, s1
	li	a1, 0
	mv	a2, s2
	call	fft
	lw	s2, %lo(d)(s4)
	blez	s2, .LBB4_8
	lui	a1, 243712
	addi	a1, a1, -1
	mv	a0, s2
	call	power
	mv	s4, a0
	addi	s2, s2, -1
	slli	s2, s2, 32
	srli	a0, s2, 30
	add	a0, a0, s1
	addi	s0, a0, 4
.LBB4_7:
	lw	a0, 0(s1)
	mv	a1, s4
	call	multiply
	sw	a0, 0(s1)
	addi	s1, s1, 4
	bne	s1, s0, .LBB4_7
.LBB4_8:
	call	stoptime
	lui	a1, %hi(a)
	addi	a1, a1, %lo(a)
	mv	a0, s3
	call	putarray
	li	a0, 0
	ld	ra, 56(sp)
	ld	s0, 48(sp)
	ld	s1, 40(sp)
	ld	s2, 32(sp)
	ld	s3, 24(sp)
	ld	s4, 16(sp)
	ld	s5, 8(sp)
	ld	s6, 0(sp)
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	.cfi_restore s3
	.cfi_restore s4
	.cfi_restore s5
	.cfi_restore s6
	addi	sp, sp, 64
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end4:
	.size	__sysy_main, .Lfunc_end4-__sysy_main
	.cfi_endproc

	.globl	main
	.p2align	1
	.type	main,@function
main:
	.cfi_startproc
	addi	sp, sp, -16
	.cfi_def_cfa_offset 16
	sd	ra, 8(sp)
	.cfi_offset ra, -8
	call	__sysy_main
	li	a0, 0
	call	putint
	li	a0, 10
	call	putch
	li	a0, 0
	ld	ra, 8(sp)
	.cfi_restore ra
	addi	sp, sp, 16
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end5:
	.size	main, .Lfunc_end5-main
	.cfi_endproc

	.type	mod,@object
	.section	.rodata,"a",@progbits
	.globl	mod
	.p2align	2, 0x0
mod:
	.word	998244353
	.size	mod, 4

	.type	d,@object
	.bss
	.globl	d
	.p2align	2, 0x0
d:
	.word	0
	.size	d, 4

	.type	maxlen,@object
	.section	.rodata,"a",@progbits
	.globl	maxlen
	.p2align	2, 0x0
maxlen:
	.word	2097152
	.size	maxlen, 4

	.type	temp,@object
	.bss
	.globl	temp
	.p2align	4, 0x0
temp:
	.zero	8388608
	.size	temp, 8388608

	.type	a,@object
	.globl	a
	.p2align	4, 0x0
a:
	.zero	8388608
	.size	a, 8388608

	.type	b,@object
	.globl	b
	.p2align	4, 0x0
b:
	.zero	8388608
	.size	b, 8388608

	.type	c,@object
	.globl	c
	.p2align	4, 0x0
c:
	.zero	8388608
	.size	c, 8388608

	.section	".note.GNU-stack","",@progbits
