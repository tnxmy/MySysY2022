	.attribute	4, 16
	.attribute	5, "rv64i2p1_m2p0_a2p1_f2p2_d2p2_c2p0_zicsr2p0_zmmul1p0_zaamo1p0_zalrsc1p0_zca1p0_zcd1p0"
	.file	"sysy_module"
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI0_0:
	.quad	360287970357415681
	.text
	.globl	get_bf_char
	.p2align	1
	.type	get_bf_char,@function
get_bf_char:
	.cfi_startproc
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sd	ra, 24(sp)
	sd	s0, 16(sp)
	sd	s1, 8(sp)
	.cfi_offset ra, -8
	.cfi_offset s0, -16
	.cfi_offset s1, -24
	lui	a0, %hi(.LCPI0_0)
	ld	s0, %lo(.LCPI0_0)(a0)
	li	s1, 58
.LBB0_1:
	call	getch
	sext.w	a1, a0
	addi	a1, a1, -35
	bltu	s1, a1, .LBB0_1
	srl	a1, s0, a1
	andi	a1, a1, 1
	beqz	a1, .LBB0_1
	ld	ra, 24(sp)
	ld	s0, 16(sp)
	ld	s1, 8(sp)
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end0:
	.size	get_bf_char, .Lfunc_end0-get_bf_char
	.cfi_endproc

	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI1_0:
	.quad	360287970357415680
.LCPI1_1:
	.quad	360287970357415681
	.text
	.globl	read_program
	.p2align	1
	.type	read_program,@function
read_program:
	.cfi_startproc
	addi	sp, sp, -48
	.cfi_def_cfa_offset 48
	sd	ra, 40(sp)
	sd	s0, 32(sp)
	sd	s1, 24(sp)
	sd	s2, 16(sp)
	sd	s3, 8(sp)
	sd	s4, 0(sp)
	.cfi_offset ra, -8
	.cfi_offset s0, -16
	.cfi_offset s1, -24
	.cfi_offset s2, -32
	.cfi_offset s3, -40
	.cfi_offset s4, -48
	lui	a0, %hi(.LCPI1_0)
	ld	s0, %lo(.LCPI1_0)(a0)
	li	s1, 58
.LBB1_1:
	call	getch
	sext.w	a1, a0
	addi	a1, a1, -35
	bltu	s1, a1, .LBB1_1
	srl	a2, s0, a1
	andi	a2, a2, 1
	bnez	a2, .LBB1_4
	bnez	a1, .LBB1_1
	j	.LBB1_9
.LBB1_4:
	lui	s3, %hi(program_length)
	lui	a1, %hi(.LCPI1_1)
	ld	s1, %lo(.LCPI1_1)(a1)
	lui	s2, %hi(program)
	addi	s2, s2, %lo(program)
	li	s0, 58
	li	s4, 35
.LBB1_5:
	lw	a1, %lo(program_length)(s3)
	slli	a1, a1, 2
	add	a1, a1, s2
	sw	a0, 0(a1)
.LBB1_6:
	call	getch
	sext.w	a1, a0
	addi	a2, a1, -35
	bltu	s0, a2, .LBB1_6
	srl	a2, s1, a2
	andi	a2, a2, 1
	beqz	a2, .LBB1_6
	lw	a2, %lo(program_length)(s3)
	addi	a2, a2, 1
	sw	a2, %lo(program_length)(s3)
	bne	a1, s4, .LBB1_5
.LBB1_9:
	call	getch
	sext.w	a0, a0
	li	a1, 105
	bne	a0, a1, .LBB1_13
	call	getint
	lui	s2, %hi(input_length)
	sw	a0, %lo(input_length)(s2)
	call	getch
	lw	a0, %lo(input_length)(s2)
	blez	a0, .LBB1_13
	li	s1, 0
	lui	s0, %hi(input)
	addi	s0, s0, %lo(input)
.LBB1_12:
	call	getch
	lw	a1, %lo(input_length)(s2)
	sw	a0, 0(s0)
	addiw	s1, s1, 1
	addi	s0, s0, 4
	blt	s1, a1, .LBB1_12
.LBB1_13:
	ld	ra, 40(sp)
	ld	s0, 32(sp)
	ld	s1, 24(sp)
	ld	s2, 16(sp)
	ld	s3, 8(sp)
	ld	s4, 0(sp)
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	.cfi_restore s3
	.cfi_restore s4
	addi	sp, sp, 48
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end1:
	.size	read_program, .Lfunc_end1-read_program
	.cfi_endproc

	.globl	run_program
	.p2align	1
	.type	run_program,@function
run_program:
	addi	sp, sp, -496
	sd	ra, 488(sp)
	sd	s0, 480(sp)
	sd	s1, 472(sp)
	sd	s2, 464(sp)
	sd	s3, 456(sp)
	addi	sp, sp, -1600
	li	a2, 1
	slli	a2, a2, 11
	addi	a0, sp, 8
	addi	s2, sp, 8
	li	a1, 0
	call	memset
	lui	a0, %hi(program_length)
	lw	a0, %lo(program_length)(a0)
	lui	a6, %hi(output_length)
	sw	zero, %lo(output_length)(a6)
	blez	a0, .LBB2_24
	li	t4, 0
	li	a7, 0
	li	a3, 0
	li	s0, 0
	lw	t5, %lo(output_length)(a6)
	lui	a2, %hi(input_length)
	lui	s1, %hi(program)
	addi	s1, s1, %lo(program)
	li	a1, 50
	lui	s3, %hi(.LJTI2_0)
	addi	s3, s3, %lo(.LJTI2_0)
	lui	t0, %hi(tape)
	addi	t0, t0, %lo(tape)
	lw	t1, %lo(input_length)(a2)
	lui	t2, %hi(input)
	addi	t2, t2, %lo(input)
	lui	t3, %hi(output)
	addi	t3, t3, %lo(output)
	li	a5, 91
	li	t6, 93
	j	.LBB2_4
.LBB2_2:
	addiw	a3, a3, 1
.LBB2_3:
	addiw	s0, s0, 1
	bge	s0, a0, .LBB2_24
.LBB2_4:
	slli	a2, s0, 2
	add	a2, a2, s1
	lw	a2, 0(a2)
	addi	a2, a2, -43
	bltu	a1, a2, .LBB2_3
	slli	a2, a2, 2
	add	a2, a2, s3
	lw	a2, 0(a2)
	jr	a2
.LBB2_6:
	slli	a2, a3, 2
	add	a2, a2, t0
	lw	a4, 0(a2)
	addi	a4, a4, 1
	sw	a4, 0(a2)
	j	.LBB2_3
.LBB2_7:
	slli	a4, a3, 2
	add	a4, a4, t0
	bge	a7, t1, .LBB2_16
	slli	a2, a7, 2
	add	a2, a2, t2
	lw	a2, 0(a2)
	sw	a2, 0(a4)
	addiw	a7, a7, 1
	j	.LBB2_3
.LBB2_9:
	slli	a2, a3, 2
	add	a2, a2, t0
	lw	a2, 0(a2)
	beqz	a2, .LBB2_17
	slli	a2, t4, 2
	add	a2, a2, s2
	sw	s0, 0(a2)
	addiw	t4, t4, 1
	j	.LBB2_3
.LBB2_11:
	slli	a2, a3, 2
	add	a2, a2, t0
	lw	a2, 0(a2)
	addiw	a4, t4, -1
	beqz	a2, .LBB2_23
	slli	a4, a4, 2
	add	a4, a4, s2
	lw	s0, 0(a4)
	j	.LBB2_3
.LBB2_13:
	slli	a2, a3, 2
	add	a2, a2, t0
	lw	a4, 0(a2)
	addi	a4, a4, -1
	sw	a4, 0(a2)
	j	.LBB2_3
.LBB2_14:
	slli	a2, a3, 2
	add	a2, a2, t0
	lw	a2, 0(a2)
	slli	a4, t5, 2
	addiw	t5, t5, 1
	add	a4, a4, t3
	sw	a2, 0(a4)
	sw	t5, %lo(output_length)(a6)
	j	.LBB2_3
.LBB2_15:
	addiw	a3, a3, -1
	j	.LBB2_3
.LBB2_16:
	sw	zero, 0(a4)
	j	.LBB2_3
.LBB2_17:
	li	a4, 1
	j	.LBB2_19
.LBB2_18:
	addiw	a4, a4, -1
	blez	a4, .LBB2_3
.LBB2_19:
	addiw	s0, s0, 1
	slli	a2, s0, 2
	add	a2, a2, s1
	lw	a2, 0(a2)
	beq	a2, a5, .LBB2_22
	beq	a2, t6, .LBB2_18
	bgtz	a4, .LBB2_19
	j	.LBB2_3
.LBB2_22:
	addiw	a4, a4, 1
	bgtz	a4, .LBB2_19
	j	.LBB2_3
.LBB2_23:
	mv	t4, a4
	j	.LBB2_3
.LBB2_24:
	addi	sp, sp, 1600
	ld	ra, 488(sp)
	ld	s0, 480(sp)
	ld	s1, 472(sp)
	ld	s2, 464(sp)
	ld	s3, 456(sp)
	addi	sp, sp, 496
	ret
.Lfunc_end2:
	.size	run_program, .Lfunc_end2-run_program
	.section	.rodata,"a",@progbits
	.p2align	2, 0x0
.LJTI2_0:
	.word	.LBB2_6
	.word	.LBB2_7
	.word	.LBB2_13
	.word	.LBB2_14
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_15
	.word	.LBB2_3
	.word	.LBB2_2
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_3
	.word	.LBB2_9
	.word	.LBB2_3
	.word	.LBB2_11

	.text
	.globl	output_
	.p2align	1
	.type	output_,@function
output_:
	.cfi_startproc
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sd	ra, 24(sp)
	sd	s0, 16(sp)
	sd	s1, 8(sp)
	sd	s2, 0(sp)
	.cfi_offset ra, -8
	.cfi_offset s0, -16
	.cfi_offset s1, -24
	.cfi_offset s2, -32
	lui	s2, %hi(output_length)
	lw	a0, %lo(output_length)(s2)
	blez	a0, .LBB3_3
	li	s1, 0
	lui	s0, %hi(output)
	addi	s0, s0, %lo(output)
.LBB3_2:
	lw	a0, 0(s0)
	call	putch
	lw	a0, %lo(output_length)(s2)
	addiw	s1, s1, 1
	addi	s0, s0, 4
	blt	s1, a0, .LBB3_2
.LBB3_3:
	ld	ra, 24(sp)
	ld	s0, 16(sp)
	ld	s1, 8(sp)
	ld	s2, 0(sp)
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end3:
	.size	output_, .Lfunc_end3-output_
	.cfi_endproc

	.globl	__sysy_main
	.p2align	1
	.type	__sysy_main,@function
__sysy_main:
	.cfi_startproc
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sd	ra, 24(sp)
	sd	s0, 16(sp)
	sd	s1, 8(sp)
	sd	s2, 0(sp)
	.cfi_offset ra, -8
	.cfi_offset s0, -16
	.cfi_offset s1, -24
	.cfi_offset s2, -32
	call	read_program
	call	starttime
	call	run_program
	call	stoptime
	lui	s2, %hi(output_length)
	lw	a0, %lo(output_length)(s2)
	blez	a0, .LBB4_3
	li	s1, 0
	lui	s0, %hi(output)
	addi	s0, s0, %lo(output)
.LBB4_2:
	lw	a0, 0(s0)
	call	putch
	lw	a0, %lo(output_length)(s2)
	addiw	s1, s1, 1
	addi	s0, s0, 4
	blt	s1, a0, .LBB4_2
.LBB4_3:
	li	a0, 0
	ld	ra, 24(sp)
	ld	s0, 16(sp)
	ld	s1, 8(sp)
	ld	s2, 0(sp)
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end4:
	.size	__sysy_main, .Lfunc_end4-__sysy_main
	.cfi_endproc

	.globl	main
	.p2align	1
	.type	main,@function
main:
	.cfi_startproc
	addi	sp, sp, -32
	.cfi_def_cfa_offset 32
	sd	ra, 24(sp)
	sd	s0, 16(sp)
	sd	s1, 8(sp)
	sd	s2, 0(sp)
	.cfi_offset ra, -8
	.cfi_offset s0, -16
	.cfi_offset s1, -24
	.cfi_offset s2, -32
	call	read_program
	call	starttime
	call	run_program
	call	stoptime
	lui	s2, %hi(output_length)
	lw	a0, %lo(output_length)(s2)
	blez	a0, .LBB5_3
	li	s1, 0
	lui	s0, %hi(output)
	addi	s0, s0, %lo(output)
.LBB5_2:
	lw	a0, 0(s0)
	call	putch
	lw	a0, %lo(output_length)(s2)
	addiw	s1, s1, 1
	addi	s0, s0, 4
	blt	s1, a0, .LBB5_2
.LBB5_3:
	li	a0, 0
	call	putint
	li	a0, 10
	call	putch
	li	a0, 0
	ld	ra, 24(sp)
	ld	s0, 16(sp)
	ld	s1, 8(sp)
	ld	s2, 0(sp)
	.cfi_restore ra
	.cfi_restore s0
	.cfi_restore s1
	.cfi_restore s2
	addi	sp, sp, 32
	.cfi_def_cfa_offset 0
	ret
.Lfunc_end5:
	.size	main, .Lfunc_end5-main
	.cfi_endproc

	.type	program_length,@object
	.bss
	.globl	program_length
	.p2align	2, 0x0
program_length:
	.word	0
	.size	program_length, 4

	.type	program,@object
	.globl	program
	.p2align	4, 0x0
program:
	.zero	262144
	.size	program, 262144

	.type	tape,@object
	.globl	tape
	.p2align	4, 0x0
tape:
	.zero	262144
	.size	tape, 262144

	.type	input,@object
	.globl	input
	.p2align	4, 0x0
input:
	.zero	262144
	.size	input, 262144

	.type	input_length,@object
	.globl	input_length
	.p2align	2, 0x0
input_length:
	.word	0
	.size	input_length, 4

	.type	output,@object
	.globl	output
	.p2align	4, 0x0
output:
	.zero	262144
	.size	output, 262144

	.type	output_length,@object
	.globl	output_length
	.p2align	2, 0x0
output_length:
	.word	0
	.size	output_length, 4

	.section	".note.GNU-stack","",@progbits
